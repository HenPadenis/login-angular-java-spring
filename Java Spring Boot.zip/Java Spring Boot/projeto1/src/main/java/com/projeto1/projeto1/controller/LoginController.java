package com.projeto1.projeto1.controller;

import com.projeto1.projeto1.model.User;
import com.projeto1.projeto1.repository.UserRepository;
import com.projeto1.projeto1.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class LoginController {

    @Autowired
    private UserService userService;


    @GetMapping
    public ResponseEntity<String> fazerLogin(@RequestParam String email, @RequestParam String senha){
        if(userService.validarLogin(email, senha)){
            return ResponseEntity.ok("Login bem-sucedido!");
        }
        else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falha ao realizar login.");
        }
    }



    @Autowired
    private UserRepository userRepository;
    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userRepository.findAll();
        for (User user : users) {
            System.out.println("User ID: " + user.getCodigo());
            System.out.println("Username: " + user.getEmail());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Senha: " + user.getSenha());
            System.out.println("Número de Celular: " + user.getCel());
            System.out.println("------------------------");
        }
        return ResponseEntity.ok(users);
    }

    @PostMapping("login")
    public ResponseEntity<String> fazerLogin(@RequestBody User user){
        if(userService.validarLogin(user.getEmail(), user.getSenha())){
            return ResponseEntity.ok("{\"message\": \"Login bem-sucedido!\"}");
        }
        else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falha ao realizar login.");
        }
    }

    @PostMapping("/cadastrar")
    public ResponseEntity<String> cadastrarUsuario(@RequestBody User user) {
        userRepository.save(user);
        return ResponseEntity.ok("{\"message\": \"Usuário cadastrado com sucesso!\"}");
    }


}
