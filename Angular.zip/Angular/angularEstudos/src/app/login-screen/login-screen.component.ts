import { Component } from '@angular/core';
import { ServerService } from '../server.service';
import { FormsModule } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-login-screen',
  standalone: true,
  imports: [
    FormsModule
  ],
  templateUrl: './login-screen.component.html',
  styleUrl: './login-screen.component.css'
})
export class LoginScreenComponent {
  //Lógica de inserir a classe active no container para fazer a animação do CSS
  public containerActive = false; //starta como false, pra não iniciar o site já trocando a animação

  toggleContainer() { //toggleContainer = alterarContainer, troca da tela de login pra de cadastro
    this.containerActive = !this.containerActive; //seta o containerActive como true
    //Na div container, é necessário colocar [class.active]="containerActive" para que a classe seja adicionada à div
    //E por fim, para disparar esse evento, basta adicionar (click)="toggleContainer()" nos botões laterais de cadastrar/entrar
  }

  //Abaixo, segue toda a estrutura para receber os dados dos inputs e chamar as funções que fazem o post pra API (funções declaradas no server.service.ts)
  constructor(private serverService: ServerService) {}

  email: string = "";
  emailCadastro: string = "";
  senha: string = "";
  nome: string = "";
  sobrenome: string = "";
  DDD: string = "";
  celComDDD: string = "";

  fazerLogin(email: string, senha: string): void {
    // const headers = new HttpHeaders({
    //   'Content-Type': 'application/json',
    //   'Authorization': 'Basic ' + btoa(`${email}:${senha}`)
    // });
    this.serverService.login(email, senha)
      .subscribe(
        (response: any) => {
          alert("Login realizado com sucesso!");
          // Lógica para tratar a resposta da API
          console.log('Resposta da API:', response);
        },
        
        (error: any) => {
          alert("Erro ao realizar login")
          // Lógica para tratar erros
          console.error('Erro na requisição:', error);
        }
      );
  }

  cadastrarUser(emailCadastro: string, senha: string, nome: string, sobrenome: string): void {
    const celularCompleto = this.DDD + this.celComDDD;
    // const headers = new HttpHeaders({
    //   'Content-Type': 'application/json',
    //   'Authorization': 'Basic ' + btoa(`${email}:${senha}`)
    // });
    this.serverService.cadastro(emailCadastro, senha, nome, sobrenome, celularCompleto)
      .subscribe(
        (response: any) => {
          // Lógica para tratar a resposta da API
          console.log('Resposta da API:', response);
        },
        
        (error: any) => {
          // Lógica para tratar erros
          console.error('Erro na requisição:', error);
        }
      );
  }


}
