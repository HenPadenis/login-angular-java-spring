import { Routes } from '@angular/router';
import { LoginScreenComponent } from './login-screen/login-screen.component';
import path from 'node:path';

export const routes: Routes = [
    { path: 'login', component: LoginScreenComponent},
];
