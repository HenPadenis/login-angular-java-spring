import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
// import { valoresPost } from './conecta/Model/respostaModel';


@Injectable({
  providedIn: 'root',
})
export class ServerService {
  constructor(private http: HttpClient) {}

  public login(email: string, senha: string): Observable<any> {
    const apiUrl = 'http://localhost:8080/api/login'
    const body = { email, senha };
    return this.http.post<any>(apiUrl, body);
  }

  public cadastro(email: string, senha: string, nome: string, sobrenome: string, cel: string): Observable<any> {
    const apiUrl = 'http://localhost:8080/api/cadastrar'
    const body = { email, senha, nome, sobrenome, cel };
    return this.http.post<any>(apiUrl, body);
  }

}
